const sequelize = require('../config/database')
const { DataTypes } = require('sequelize')

const Invite = sequelize.define('Invite', {
  inviterId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  inviteeId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true,
    unique: true
  },
  inviteeGender: {
    type: DataTypes.TINYINT,
    allowNull: true
  },
  totalReward: {
    type: DataTypes.BIGINT,
    defaultValue: 0
  },
  status: {
    type: DataTypes.ENUM('active', 'inactive'),
    defaultValue: 'active'
  }
}, {
  tableName: 'invites',
  indexes: [
    { fields: ['inviterId'] },
    { fields: ['inviteeId'], unique: true },
    { fields: ['status'] }
  ]
})

module.exports = Invite
