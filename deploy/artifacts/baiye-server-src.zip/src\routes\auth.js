const express = require('express')
const router = express.Router()
const rateLimit = require('express-rate-limit')
const { User, Wallet } = require('../models')
const { signToken, signRefreshToken } = require('../middleware/auth')
const { success, fail } = require('../utils/response')
const sms = require('../utils/sms')

// 短信发送频控：同一 IP 每分钟 1 次，每小时 10 次
// - 生产/开发：强约束，避免短信被刷
// - Jest 自动化 (NODE_ENV=test)：禁用限流，确保每个用例都可独立登录断言（短信本身会落到内存验证码）
const smsLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: process.env.NODE_ENV === 'test' ? 9999 : 1,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 429, message: '发送过于频繁，请稍后再试' }
})
const smsHourLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: process.env.NODE_ENV === 'test' ? 99999 : 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: 429, message: '本小时发送次数已达上限' }
})

/** 发送短信验证码 — 生产级：真实网关发送，除 Jest(NODE_ENV=test) 外响应永不包含明文验证码 */
async function handleSendSms(req, res) {
  const { phone, scene = 'login' } = req.body
  if (!/^1\d{10}$/.test(phone)) return fail(res, '手机号格式不正确')
  const result = await sms.sendCode(phone, scene)
  if (!result.success) return fail(res, result.message)
  // 仅 Jest 自动化（NODE_ENV=test）回传验证码方便断言；
  // 生产/开发模式一律不回传明文验证码，前端只展示倒计时。
  if (process.env.NODE_ENV === 'test') {
    success(res, { code: result.code }, '[TEST] 验证码已生成（仅用于自动化测试）')
  } else {
    success(res, {}, '验证码已发送，请留意短信')
  }
}
// 兼容两种命名：/api/auth/sms 为内部标准命名；/api/auth/send-code 为对外常见别名
router.post('/sms', smsLimiter, smsHourLimiter, async (req, res, next) => {
  try { await handleSendSms(req, res) } catch (err) { next(err) }
})
router.post('/send-code', smsLimiter, smsHourLimiter, async (req, res, next) => {
  try { await handleSendSms(req, res) } catch (err) { next(err) }
})

/** 登录/注册 */
router.post('/login', async (req, res, next) => {
  try {
    const { phone, code, scene = 'login' } = req.body
    if (!/^1\d{10}$/.test(phone)) return fail(res, '手机号格式不正确')
    if (!code) return fail(res, '请输入验证码')

    const ok = await sms.verifyCode(phone, code, scene)
    if (!ok) return fail(res, '验证码错误或已过期')

    // 查找或创建用户
    let user = await User.findOne({ where: { phone } })
    let created = false
    if (!user) {
      user = await User.create({
        phone,
        nickname: `用户${phone.slice(-4)}`,
        inviteCode: 'INV' + Date.now().toString(36).toUpperCase()
      })
      await Wallet.create({ userId: user.id })
      created = true
    }

    const token = signToken(user.id)
    const refreshToken = signRefreshToken(user.id)
    await user.update({ lastLoginAt: new Date().toISOString() })

    success(res, {
      token,
      refreshToken,
      user: {
        id: user.id,
        phone: user.phone,
        nickname: user.nickname,
        avatar: user.avatar,
        isElite: user.isElite,
        isNew: created
      }
    }, '登录成功')
  } catch (err) { next(err) }
})

/** 退出登录 */
router.post('/logout', (req, res) => {
  success(res, null, '已退出')
})

module.exports = router
