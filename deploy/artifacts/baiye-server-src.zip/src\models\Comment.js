const sequelize = require('../config/database')
const { DataTypes } = require('sequelize')

const Comment = sequelize.define('Comment', {
  postId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: false
  },
  userId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: false
  },
  replyToUserId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  text: {
    type: DataTypes.STRING(500),
    allowNull: false
  },
  blocked: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  auditStatus: {
    type: DataTypes.ENUM('pending', 'approved', 'rejected', 'blocked'),
    defaultValue: 'approved'
  }
}, {
  tableName: 'comments',
  indexes: [
    { fields: ['postId'] },
    { fields: ['userId'] },
    { fields: ['replyToUserId'] },
    { fields: ['auditStatus'] }
  ]
})

module.exports = Comment
