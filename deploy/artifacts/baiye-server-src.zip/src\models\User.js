const sequelize = require('../config/database')
const { DataTypes } = require('sequelize')

const User = sequelize.define('User', {
  phone: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true
  },
  nickname: {
    type: DataTypes.STRING(50),
    defaultValue: '用户'
  },
  avatar: {
    type: DataTypes.STRING(500),
    allowNull: true
  },
  gender: {
    type: DataTypes.TINYINT,
    defaultValue: 0
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  bio: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  isElite: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  isProvider: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  realPersonStatus: {
    type: DataTypes.ENUM('none', 'pending', 'passed', 'rejected'),
    defaultValue: 'none'
  },
  identityStatus: {
    type: DataTypes.ENUM('none', 'pending', 'passed', 'rejected'),
    defaultValue: 'none'
  },
  inviteCode: {
    type: DataTypes.STRING(20),
    allowNull: true,
    unique: true
  },
  inviterId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  status: {
    type: DataTypes.TINYINT,
    defaultValue: 1
  },
  lastLoginAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  meta: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: null
  }
}, {
  tableName: 'users',
  indexes: [
    { fields: ['phone'], unique: true },
    { fields: ['inviteCode'], unique: true },
    { fields: ['city'] },
    { fields: ['status'] },
    { fields: ['isElite'] },
    { fields: ['isProvider'] },
    { fields: ['inviterId'] }
  ]
})

/** 兼容旧 JSON 层的 findOrCreate 用法 */
if (typeof User.findOrCreate !== 'function') {
  User.findOrCreate = async function ({ where, defaults = {} }) {
    let row = await this.findOne({ where })
    if (row) return [row, false]
    const created = await this.create({ ...where, ...defaults })
    return [created, true]
  }
}

module.exports = User
