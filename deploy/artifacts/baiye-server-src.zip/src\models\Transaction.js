const sequelize = require('../config/database')
const { DataTypes } = require('sequelize')

const Transaction = sequelize.define('Transaction', {
  userId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  type: {
    type: DataTypes.ENUM('recharge', 'exchange', 'consume', 'income', 'withdraw', 'refund', 'reward')
  },
  amount: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  currency: {
    type: DataTypes.STRING(10),
    defaultValue: 'fen'
  },
  balanceAfter: {
    type: DataTypes.BIGINT,
    allowNull: true
  },
  orderId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  remark: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  extra: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: null
  }
}, {
  tableName: 'transactions',
  indexes: [
    { fields: ['userId'] },
    { fields: ['type'] },
    { fields: ['orderId'] },
    { fields: ['createdAt'] }
  ]
})

module.exports = Transaction
