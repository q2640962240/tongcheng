const express = require('express')
const router = express.Router()
const { Message, User } = require('../models')
const { auth } = require('../middleware/auth')
const { success, paginate, fail } = require('../utils/response')

/** 会话 ID：两个用户 ID 排序后拼接 */
const sessionId = (a, b) => [Number(a), Number(b)].sort((x, y) => x - y).join('-')

/** 会话列表 */
router.get('/sessions', auth, async (req, res, next) => {
  try {
    const all = await Message.findAll({
      where: {
        or: [
          { senderId: req.userId },
          { receiverId: req.userId }
        ]
      },
      order: [['createdAt', 'DESC']]
    })

    const sessionMap = new Map()
    for (const m of all) {
      const otherId = m.senderId === req.userId ? m.receiverId : m.senderId
      const sid = sessionId(req.userId, otherId)
      if (!sessionMap.has(sid)) {
        const other = await User.findByPk(otherId)
        sessionMap.set(sid, {
          sessionId: sid,
          otherUser: other ? {
            id: other.id, nickname: other.nickname, avatar: other.avatar, isElite: other.isElite
          } : null,
          lastMessage: m.content,
          lastMessageType: m.type,
          lastMessageTime: m.createdAt,
          unreadCount: 0
        })
      }
      if (m.receiverId === req.userId && !m.isRead) {
        sessionMap.get(sid).unreadCount++
      }
    }
    success(res, [...sessionMap.values()])
  } catch (err) { next(err) }
})

/** 历史消息 */
router.get('/history/:userId', auth, async (req, res, next) => {
  try {
    const otherId = req.params.userId
    const sid = sessionId(req.userId, otherId)
    const { page = 1, pageSize = 50 } = req.query
    const { rows, count } = await Message.findAndCountAll({
      where: {
        or: [
          { senderId: req.userId, receiverId: otherId },
          { senderId: otherId, receiverId: req.userId }
        ]
      },
      order: [['createdAt', 'ASC']],
      offset: (page - 1) * pageSize,
      limit: Number(pageSize)
    })

    // 标记已读
    for (const m of rows) {
      if (m.receiverId === req.userId && !m.isRead) {
        await m.update({ isRead: true })
      }
    }

    paginate(res, rows, count, page, pageSize)
  } catch (err) { next(err) }
})

/** 发送消息（HTTP 备用通道；实时消息走 WebSocket） */
router.post('/', auth, async (req, res, next) => {
  try {
    const { receiverId, type = 'text', content, duration } = req.body
    if (!receiverId || !content) return fail(res, '参数不完整')

    const other = await User.findByPk(receiverId)
    if (!other) return fail(res, '用户不存在', 404)

    const message = await Message.create({
      sessionId: sessionId(req.userId, receiverId),
      senderId: req.userId,
      receiverId,
      type,
      content,
      duration,
      isRead: false
    })

    // 通过 WebSocket 推送给接收方
    if (req.app.get('io')) {
      req.app.get('io').to(`user_${receiverId}`).emit('message', message.toJSON())
    }

    // 离线推送（接收方不在线时收到推送通知）
    const sender = await User.findByPk(req.userId)
    const senderName = sender ? sender.nickname : '新消息'
    const preview = type === 'voice' ? '[语音消息]' : type === 'image' ? '[图片]' : content
    const push = require('../utils/push')
    push.pushToUser(receiverId, {
      title: senderName,
      body: preview.length > 30 ? preview.slice(0, 30) + '...' : preview,
      extras: { type: 'im', sessionId: sessionId(req.userId, receiverId), senderId: req.userId }
    }).catch(() => {})

    success(res, message, '发送成功')
  } catch (err) { next(err) }
})

module.exports = router
