const sequelize = require('../config/database')
const { DataTypes } = require('sequelize')

const Review = sequelize.define('Review', {
  orderId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  serviceId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  userId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  providerId: {
    type: DataTypes.BIGINT.UNSIGNED,
    allowNull: true
  },
  rating: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  images: {
    type: DataTypes.JSON,
    allowNull: true,
    defaultValue: null
  },
  isAnonymous: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  tableName: 'reviews',
  indexes: [
    { fields: ['orderId'] },
    { fields: ['serviceId'] },
    { fields: ['userId'] },
    { fields: ['providerId'] }
  ]
})

module.exports = Review
