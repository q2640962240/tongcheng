import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getConfigModules, updateConfigModule, testConfigModule, resetConfigModule } from '../api'

export const useConfigStore = defineStore('config', () => {
  const modules = ref([])
  const loading = ref(false)
  const saving = ref(false)

  const loadModules = async () => {
    loading.value = true
    try {
      const res = await getConfigModules()
      modules.value = res.data || []
    } catch (e) {} finally {
      loading.value = false
    }
  }

  const saveModule = async (name, values) => {
    saving.value = true
    try {
      await updateConfigModule(name, values)
      // 保存后刷新当前模块的展示值（敏感字段打码）
      const res = await getConfigModules()
      modules.value = res.data || []
      return true
    } catch (e) {
      return false
    } finally {
      saving.value = false
    }
  }

  const testModule = async (name) => {
    try {
      const res = await testConfigModule(name)
      return res.data
    } catch (e) {
      return { success: false, message: '测试失败' }
    }
  }

  const resetModule = async (name) => {
    try {
      await resetConfigModule(name)
      await loadModules()
      return true
    } catch (e) {
      return false
    }
  }

  return { modules, loading, saving, loadModules, saveModule, testModule, resetModule }
})
