<template>
  <div class="services">
    <div class="page-card">
      <div class="filter-bar">
        <el-select v-model="filters.status" placeholder="状态" clearable style="width: 140px">
          <el-option label="待审核" value="pending" />
          <el-option label="已上线" value="online" />
          <el-option label="已下线" value="offline" />
          <el-option label="已拒绝" value="rejected" />
        </el-select>
        <el-select v-model="filters.category" placeholder="分类" clearable style="width: 140px">
          <el-option label="暖心服务" value="warm" />
          <el-option label="游戏陪玩" value="game" />
          <el-option label="线下约玩" value="offline" />
        </el-select>
        <el-button type="primary" @click="loadData">查询</el-button>
      </div>
    </div>

    <div class="page-card">
      <el-table :data="list" v-loading="loading" border>
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="title" label="服务标题" min-width="160" />
        <el-table-column prop="category" label="分类" width="120">
          <template #default="{ row }">
            <el-tag size="small">{{ categoryMap[row.category] || row.category }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="price" label="价格" width="120">
          <template #default="{ row }">¥{{ row.price }} / {{ row.priceUnit }}</template>
        </el-table-column>
        <el-table-column prop="orderCount" label="订单数" width="100" />
        <el-table-column prop="ratingAvg" label="评分" width="80" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" size="small">{{ statusMap[row.status] }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <template v-if="row.status === 'pending'">
              <el-button size="small" type="success" @click="onAudit(row, 'online')">通过</el-button>
              <el-button size="small" type="danger" @click="onAudit(row, 'rejected')">拒绝</el-button>
            </template>
            <el-button size="small" @click="onToggleOnline(row)">
              {{ row.status === 'online' ? '下线' : '上线' }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[20, 50]"
        layout="total, sizes, prev, pager, next"
        @size-change="loadData"
        @current-change="loadData"
        style="margin-top: 16px; justify-content: flex-end"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getServices, auditService } from '../../api'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = reactive({ status: '', category: '' })

const categoryMap = { warm: '暖心服务', game: '游戏陪玩', offline: '线下约玩' }
const statusMap = { pending: '待审核', online: '已上线', offline: '已下线', rejected: '已拒绝' }
const statusType = (s) => ({ pending: 'warning', online: 'success', offline: 'info', rejected: 'danger' })[s] || 'info'

const loadData = async () => {
  loading.value = true
  try {
    const res = await getServices({ ...filters, page: page.value, pageSize: pageSize.value })
    list.value = res.data.list
    total.value = res.data.total
  } catch (e) {} finally { loading.value = false }
}

const onAudit = async (row, status) => {
  try {
    await auditService(row.id, { status })
    ElMessage.success(status === 'online' ? '已通过审核' : '已拒绝')
    loadData()
  } catch (e) {}
}

const onToggleOnline = async (row) => {
  const status = row.status === 'online' ? 'offline' : 'online'
  try {
    await auditService(row.id, { status })
    ElMessage.success('操作成功')
    loadData()
  } catch (e) {}
}

onMounted(loadData)
</script>

<style lang="scss" scoped>
.filter-bar { display: flex; gap: 12px; align-items: center; }
</style>
