<template>
  <div class="users">
    <div class="page-card">
      <div class="filter-bar">
        <el-input
          v-model="filters.keyword"
          placeholder="搜索昵称/手机号"
          clearable
          style="width: 240px"
          @keyup.enter="loadData"
        />
        <el-select v-model="filters.isElite" placeholder="精英认证" clearable style="width: 140px">
          <el-option label="精英" :value="true" />
          <el-option label="普通" :value="false" />
        </el-select>
        <el-select v-model="filters.status" placeholder="状态" clearable style="width: 120px">
          <el-option label="正常" :value="1" />
          <el-option label="禁用" :value="0" />
        </el-select>
        <el-button type="primary" @click="loadData">查询</el-button>
      </div>
    </div>

    <div class="page-card">
      <el-table :data="list" v-loading="loading" border>
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="头像" width="80">
          <template #default="{ row }">
            <el-avatar :size="40" :src="row.avatar">{{ row.nickname?.[0] }}</el-avatar>
          </template>
        </el-table-column>
        <el-table-column prop="nickname" label="昵称" min-width="120" />
        <el-table-column prop="phone" label="手机号" width="140" />
        <el-table-column label="性别" width="80">
          <template #default="{ row }">
            {{ ['未知', '男', '女'][row.gender] }}
          </template>
        </el-table-column>
        <el-table-column label="精英" width="80">
          <template #default="{ row }">
            <el-tag v-if="row.isElite" type="warning" size="small">精英</el-tag>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="inviteCode" label="邀请码" width="140" />
        <el-table-column label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'danger'" size="small">
              {{ row.status === 1 ? '正常' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="注册时间" width="180">
          <template #default="{ row }">
            {{ formatTime(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="onDetail(row)">详情</el-button>
            <el-button
              size="small"
              :type="row.status === 1 ? 'danger' : 'success'"
              @click="onToggleStatus(row)"
            >{{ row.status === 1 ? '封禁' : '解封' }}</el-button>
            <el-button
              v-if="!row.isElite"
              size="small"
              type="warning"
              @click="onApproveElite(row)"
            >通过精英</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="page"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[20, 50, 100]"
        layout="total, sizes, prev, pager, next"
        @size-change="loadData"
        @current-change="loadData"
        style="margin-top: 16px; justify-content: flex-end"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getUsers, updateUserStatus, auditElite } from '../../api'

const loading = ref(false)
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = reactive({ keyword: '', isElite: '', status: '' })

const formatTime = (ts) => {
  if (!ts) return '-'
  const d = new Date(ts)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

const loadData = async () => {
  loading.value = true
  try {
    const res = await getUsers({ ...filters, page: page.value, pageSize: pageSize.value })
    list.value = res.data.list
    total.value = res.data.total
  } catch (e) {} finally {
    loading.value = false
  }
}

const onToggleStatus = async (row) => {
  try {
    await ElMessageBox.confirm(`确认${row.status === 1 ? '封禁' : '解封'}用户 ${row.nickname}?`, '提示', { type: 'warning' })
    await updateUserStatus(row.id, row.status === 1 ? 0 : 1)
    ElMessage.success('操作成功')
    loadData()
  } catch (e) {}
}

const onApproveElite = async (row) => {
  try {
    await ElMessageBox.confirm(`确认通过 ${row.nickname} 的精英认证?`, '精英认证审核', { type: 'warning' })
    await auditElite(row.id, true)
    ElMessage.success('已通过精英认证')
    loadData()
  } catch (e) {}
}

const onDetail = (row) => {
  ElMessage.info(`用户详情开发中：${row.nickname}`)
}

onMounted(loadData)
</script>

<style lang="scss" scoped>
.filter-bar { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
</style>
