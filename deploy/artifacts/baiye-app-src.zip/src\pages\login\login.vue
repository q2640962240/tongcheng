<template>
  <view class="page">
    <!-- 照片墙背景 -->
    <image class="bg" src="/static/login-photo-wall.png" mode="aspectFill" />
    <view class="overlay"></view>

    <view class="content">
      <view class="brand">
        <view class="logo">伴</view>
        <text class="brand-name">白夜</text>
      </view>
      <text class="slogan">白夜 · 陪你度过每一刻</text>

      <view class="form">
        <view class="input-group">
          <text class="label">手机号</text>
          <input
            v-model="phone"
            class="input"
            type="number"
            maxlength="11"
            placeholder="请输入手机号"
          />
        </view>
        <view class="input-group">
          <text class="label">验证码</text>
          <view class="code-row">
            <input
              v-model="code"
              class="input code-input"
              type="number"
              maxlength="6"
              placeholder="请输入验证码"
            />
            <view
              class="code-btn"
              :class="{ disabled: counting > 0 }"
              @tap="onSendCode"
            >{{ counting > 0 ? `${counting}s` : '获取验证码' }}</view>
          </view>
        </view>

        <view class="btn-login" @tap="onLogin">登录 / 注册</view>
      </view>

      <view class="agreement">
        <text>登录即代表同意</text>
        <text class="link">《用户协议》</text>
        <text>和</text>
        <text class="link">《隐私政策》</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { useUserStore } from '../../store/user'

const userStore = useUserStore()
const phone = ref('')
const code = ref('')
const counting = ref(0)

const onSendCode = async () => {
  if (counting.value > 0) return
  if (!/^1\d{10}$/.test(phone.value)) {
    uni.showToast({ title: '请输入正确的手机号', icon: 'none' })
    return
  }
  try {
    const res = await userStore.sendCode(phone.value)
    // 开发环境后端会返回验证码，直接填充方便测试
    if (res && res.code) {
      code.value = res.code
      uni.showToast({ title: `验证码：${res.code}`, icon: 'none', duration: 3000 })
    } else {
      uni.showToast({ title: '验证码已发送', icon: 'success' })
    }
    counting.value = 60
    const timer = setInterval(() => {
      counting.value--
      if (counting.value <= 0) clearInterval(timer)
    }, 1000)
  } catch (e) {
    // 错误已在 request 层提示
  }
}

const onLogin = async () => {
  if (!/^1\d{10}$/.test(phone.value)) {
    uni.showToast({ title: '请输入正确的手机号', icon: 'none' })
    return
  }
  if (code.value.length < 4) {
    uni.showToast({ title: '请输入验证码', icon: 'none' })
    return
  }
  try {
    await userStore.loginByCode(phone.value, code.value)
    uni.showToast({ title: '登录成功', icon: 'success' })
    setTimeout(() => uni.switchTab({ url: '/pages/home/home' }), 500)
  } catch (e) {
    // 错误已在 request 层提示
  }
}
</script>

<style lang="scss" scoped>
.page {
  position: relative;
  min-height: 100vh;
  overflow: hidden;
}
.bg {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
}
.overlay {
  position: absolute;
  top: 0; left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(180deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.6) 100%);
}
.content {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 200rpx 48rpx 80rpx;
  min-height: 100vh;
  justify-content: space-between;
}
.brand {
  display: flex;
  align-items: center;
  gap: 16rpx;
}
.logo {
  width: 80rpx;
  height: 80rpx;
  border-radius: 24rpx;
  background: #ffd60a;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40rpx;
  font-weight: 700;
}
.brand-name {
  font-size: 56rpx;
  font-weight: 700;
  color: #ffffff;
}
.slogan {
  margin-top: 16rpx;
  font-size: 28rpx;
  color: rgba(255, 255, 255, 0.85);
}
.form {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 32rpx;
}
.input-group {
  display: flex;
  flex-direction: column;
  gap: 12rpx;
}
.label {
  font-size: 26rpx;
  color: rgba(255, 255, 255, 0.9);
}
.input {
  height: 96rpx;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16rpx;
  padding: 0 24rpx;
  font-size: 30rpx;
  color: #171717;
}
.code-row {
  display: flex;
  gap: 16rpx;
}
.code-input { flex: 1; }
.code-btn {
  width: 220rpx;
  height: 96rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ffd60a;
  color: #171717;
  border-radius: 16rpx;
  font-size: 26rpx;
  font-weight: 600;
  white-space: nowrap;
  &.disabled {
    background: #e5e5e5;
    color: #737373;
  }
}
.btn-login {
  height: 96rpx;
  background: #ffd60a;
  color: #171717;
  border-radius: 9999rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32rpx;
  font-weight: 700;
  margin-top: 16rpx;
  &:active { opacity: 0.9; }
}
.agreement {
  font-size: 24rpx;
  color: rgba(255, 255, 255, 0.7);
  text-align: center;
}
.link {
  color: #ffd60a;
}
</style>
