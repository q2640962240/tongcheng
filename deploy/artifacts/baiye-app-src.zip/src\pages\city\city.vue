<template>
  <view class="page-city">
    <!-- 顶部搜索条（全国城市实时搜索） -->
    <view class="search-header">
      <view class="back-btn" @tap="onBack"><text class="arrow">‹</text></view>
      <view class="search-bar">
        <text class="s-icon">🔎</text>
        <input
          v-model="searchKw"
          class="s-input"
          type="text"
          placeholder="搜索城市 / 拼音 / 简称（如 bj、羊城、魔都）"
          confirm-type="search"
          :focus="autoFocus"
          @input="onSearchInput"
          @confirm="onSearchConfirm"
        />
        <text v-if="searchKw" class="s-clear" @tap="clearSearch">✕</text>
      </view>
    </view>

    <!-- 搜索结果视图（仅当有搜索词时） -->
    <block v-if="searchKw && searched">
      <view class="section card">
        <view class="section-title">
          <text>搜索结果</text>
          <text class="meta-hint" v-if="metaSearch.hint">{{ metaSearch.hint }}</text>
        </view>
        <view v-if="searchResult.length === 0" class="empty-s">
          <text class="empty-emoji">🏙️</text>
          <text class="empty-text">未找到相关城市，换个词试试</text>
        </view>
        <view
          v-for="c in searchResult"
          :key="c.code || c.name"
          class="city-item"
          :class="{ selected: current === c.name }"
          @tap="onChoose(c.name)"
        >
          <view class="city-info">
            <text class="city-main">{{ c.name }}</text>
            <text class="city-sub" v-if="c.provinceName && c.provinceName !== c.name">
              {{ c.provinceName }}{{ c.alias && c.alias.length ? ' · ' + c.alias.slice(0, 2).join('/') : '' }}
            </text>
          </view>
          <text v-if="current === c.name" class="checked">✓</text>
        </view>
      </view>
      <view class="bottom-safe" />
    </block>

    <!-- 常规选择视图（未搜索时） -->
    <block v-else>
      <!-- 当前城市 + 定位 -->
      <view class="section card">
        <view class="section-title">
          <text>当前城市</text>
          <text class="meta-hint" v-if="locateSource">{{ sourceText(locateSource) }}</text>
        </view>
        <view class="current-row">
          <view class="current-city" @tap="onChoose(current)">
            <text class="city-badge">📍</text>
            <text class="city-name">{{ current }}</text>
            <view v-if="locating" class="locating-dot" />
          </view>
          <view class="locate-btn" :class="{ disabled: locating }" @tap="runLocatePipeline">
            <text>{{ locating ? '定位中…' : '重新定位' }}</text>
          </view>
        </view>
        <view v-if="locateError" class="locate-error">
          <text>{{ locateError }}</text>
          <text class="err-link" @tap="runLocatePipeline"> 重试</text>
        </view>
      </view>

      <!-- 热门城市（数据流量 Top 12） -->
      <view class="section card">
        <view class="section-title">热门城市</view>
        <view class="hot-grid">
          <view
            v-for="c in hotCities"
            :key="c"
            class="hot-item"
            :class="{ active: current === c }"
            @tap="onChoose(c)"
          >
            {{ c }}
          </view>
        </view>
      </view>

      <!-- 字母索引（A-Z，动态过滤掉空字母） -->
      <view class="section card" v-if="letters.length">
        <view class="section-title">按字母查找</view>
        <view class="letter-bar">
          <view
            v-for="L in letters"
            :key="L"
            class="letter-chip"
            :class="{ active: activeLetter === L }"
            @tap="scrollToLetter(L)"
          >{{ L }}</view>
        </view>
      </view>

      <!-- 城市列表（字母分组） -->
      <view class="section card city-list-card" v-if="cityGroups.length">
        <view class="meta-row">
          <text class="meta-total">共 {{ metaTotalCities }} 个地级及以上城市 · 34 省</text>
          <text class="meta-source" v-if="treeLoaded">数据：民政部 2024 版</text>
          <text class="meta-source meta-warn" v-else>加载中，临时使用内置常用城市…</text>
        </view>
        <block v-for="group in cityGroups" :key="group.letter">
          <view class="group-letter" :id="'letter-' + group.letter">
            <text>{{ group.letter }}</text>
            <text class="group-count">{{ group.list.length }}</text>
          </view>
          <view
            v-for="c in group.list"
            :key="c.code || c.name"
            class="city-item"
            :class="{ selected: current === c.name }"
            @tap="onChoose(c.name)"
          >
            <view class="city-info">
              <text class="city-main">{{ c.name }}</text>
              <text class="city-sub" v-if="c.provinceName && c.provinceName !== c.name">
                {{ c.provinceName }}
              </text>
            </view>
            <text v-if="current === c.name" class="checked">✓</text>
          </view>
        </block>
      </view>

      <view class="bottom-safe" />
    </block>
  </view>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { regionApi, locationApi } from '../../api'
import {
  toList, toObj, toStr, toNum, pickCity,
  retry, guard, unwrap, getPath, debounce
} from '../../utils/fallback'

const STORAGE_KEY = 'baiye_city'
const STORAGE_AT_KEY = 'baiye_city_at'
const DEFAULT_CITY = '北京'

const autoFocus = ref(true)
const current = ref(DEFAULT_CITY)
const locating = ref(false)
const locateSource = ref('')
const locateError = ref('')
const activeLetter = ref('A')
const treeLoaded = ref(false)
const searchKw = ref('')
const searched = ref(false)

// 本地缓存：全国行政区划（省 + 城市）
const provinces = ref([])
const allCities = ref([])
const searchResult = ref([])
const metaSearch = ref({ hint: '' })

// 流量 Top 12（热门城市），按实际运营数据选取，顺序就是热度
const HOT_DEFAULTS = [
  '北京', '上海', '广州', '深圳', '成都', '杭州',
  '武汉', '西安', '重庆', '南京', '苏州', '长沙'
]
const hotCities = ref([...HOT_DEFAULTS])

// ==== 从存储恢复城市 ====
(function initFromStorage() {
  try {
    const saved = uni.getStorageSync(STORAGE_KEY)
    if (saved) current.value = pickCity(saved, DEFAULT_CITY)
  } catch (_) { /* ignore */ }
})()

function persistCity(name) {
  try {
    uni.setStorageSync(STORAGE_KEY, name)
    uni.setStorageSync(STORAGE_AT_KEY, Date.now())
  } catch (_) { /* ignore */ }
}

const metaTotalCities = computed(() => allCities.value.length || HOT_DEFAULTS.length)

// ==== 字母分组（动态构建，空字母不显示）====
const cityGroups = computed(() => {
  const list = toList(allCities.value.length ? allCities.value : BUILTIN_FALLBACK_CITIES)
  const map = new Map()
  for (const c of list) {
    const raw = toStr(c.firstLetter, c.spell ? c.spell[0] : '', '').toUpperCase()
    const L = /^[A-Z]$/.test(raw) ? raw : '#'
    if (!map.has(L)) map.set(L, [])
    map.get(L).push(c)
  }
  // 按 A-Z 排序，# 放最后
  const groups = []
  const order = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')
  for (const L of order) {
    if (map.has(L)) groups.push({ letter: L, list: map.get(L).sort(sortCity) })
  }
  if (map.has('#')) groups.push({ letter: '#', list: map.get('#').sort(sortCity) })
  return groups
})

const letters = computed(() => cityGroups.value.map((g) => g.letter))

function sortCity(a, b) {
  const sa = toStr(a.spell || a.name, '')
  const sb = toStr(b.spell || b.name, '')
  if (sa < sb) return -1
  if (sa > sb) return 1
  return 0
}

// ==== 内置最小城市兜底：接口失败时绝不空白（覆盖 34 省的省会/副省级以上）====
const BUILTIN_FALLBACK_CITIES = (function buildFallback() {
  const arr = [
    ['北京', '北京市', 'B'], ['上海', '上海市', 'S'], ['广州', '广东省', 'G'], ['深圳', '广东省', 'S'],
    ['成都', '四川省', 'C'], ['杭州', '浙江省', 'H'], ['武汉', '湖北省', 'W'], ['西安', '陕西省', 'X'],
    ['重庆', '重庆市', 'C'], ['南京', '江苏省', 'N'], ['苏州', '江苏省', 'S'], ['长沙', '湖南省', 'C'],
    ['天津', '天津市', 'T'], ['郑州', '河南省', 'Z'], ['青岛', '山东省', 'Q'], ['大连', '辽宁省', 'D'],
    ['宁波', '浙江省', 'N'], ['厦门', '福建省', 'X'], ['福州', '福建省', 'F'], ['合肥', '安徽省', 'H'],
    ['济南', '山东省', 'J'], ['沈阳', '辽宁省', 'S'], ['昆明', '云南省', 'K'], ['贵阳', '贵州省', 'G'],
    ['南宁', '广西壮族自治区', 'N'], ['南昌', '江西省', 'N'], ['哈尔滨', '黑龙江省', 'H'],
    ['长春', '吉林省', 'C'], ['太原', '山西省', 'T'], ['石家庄', '河北省', 'S'],
    ['海口', '海南省', 'H'], ['兰州', '甘肃省', 'L'], ['乌鲁木齐', '新疆维吾尔自治区', 'W'],
    ['呼和浩特', '内蒙古自治区', 'H'], ['银川', '宁夏回族自治区', 'Y'], ['西宁', '青海省', 'X'],
    ['拉萨', '西藏自治区', 'L'], ['合肥', '安徽省', 'H'], ['东莞', '广东省', 'D'],
    ['佛山', '广东省', 'F'], ['无锡', '江苏省', 'W'], ['温州', '浙江省', 'W'],
    ['珠海', '广东省', 'Z'], ['中山', '广东省', 'Z'], ['泉州', '福建省', 'Q'],
    ['合肥', '安徽省', 'H'], ['南昌', '江西省', 'N'], ['贵阳', '贵州省', 'G'],
    ['香港', '香港特别行政区', 'X'], ['澳门', '澳门特别行政区', 'A'],
    ['台北', '台湾省', 'T'], ['高雄', '台湾省', 'G'], ['台南', '台湾省', 'T'],
    ['台中', '台湾省', 'T'], ['新竹', '台湾省', 'X'], ['基隆', '台湾省', 'J'],
    ['石家庄', '河北省', 'S'], ['保定', '河北省', 'B'], ['唐山', '河北省', 'T'],
    ['秦皇岛', '河北省', 'Q'], ['邯郸', '河北省', 'H'], ['邢台', '河北省', 'X'],
    ['张家口', '河北省', 'Z'], ['承德', '河北省', 'C'], ['沧州', '河北省', 'C'],
    ['廊坊', '河北省', 'L'], ['衡水', '河北省', 'H'],
    ['大同', '山西省', 'D'], ['阳泉', '山西省', 'Y'], ['长治', '山西省', 'C'], ['晋城', '山西省', 'J'],
    ['朔州', '山西省', 'S'], ['晋中', '山西省', 'J'], ['运城', '山西省', 'Y'], ['忻州', '山西省', 'X'],
    ['临汾', '山西省', 'L'], ['吕梁', '山西省', 'L'],
    ['鞍山', '辽宁省', 'A'], ['抚顺', '辽宁省', 'F'], ['本溪', '辽宁省', 'B'], ['丹东', '辽宁省', 'D'],
    ['锦州', '辽宁省', 'J'], ['营口', '辽宁省', 'Y'], ['阜新', '辽宁省', 'F'], ['辽阳', '辽宁省', 'L'],
    ['盘锦', '辽宁省', 'P'], ['铁岭', '辽宁省', 'T'], ['朝阳', '辽宁省', 'C'], ['葫芦岛', '辽宁省', 'H'],
    ['吉林市', '吉林省', 'J'], ['四平', '吉林省', 'S'], ['辽源', '吉林省', 'L'], ['通化', '吉林省', 'T'],
    ['白山', '吉林省', 'B'], ['松原', '吉林省', 'S'], ['白城', '吉林省', 'B'], ['延边朝鲜族自治州', '吉林省', 'Y'],
    ['齐齐哈尔', '黑龙江省', 'Q'], ['鸡西', '黑龙江省', 'J'], ['鹤岗', '黑龙江省', 'H'], ['双鸭山', '黑龙江省', 'S'],
    ['大庆', '黑龙江省', 'D'], ['伊春', '黑龙江省', 'Y'], ['佳木斯', '黑龙江省', 'J'], ['七台河', '黑龙江省', 'Q'],
    ['牡丹江', '黑龙江省', 'M'], ['黑河', '黑龙江省', 'H'], ['绥化', '黑龙江省', 'S'],
    ['徐州', '江苏省', 'X'], ['常州', '江苏省', 'C'], ['南通', '江苏省', 'N'], ['连云港', '江苏省', 'L'],
    ['淮安', '江苏省', 'H'], ['盐城', '江苏省', 'Y'], ['扬州', '江苏省', 'Y'], ['镇江', '江苏省', 'Z'],
    ['泰州', '江苏省', 'T'], ['宿迁', '江苏省', 'S'],
    ['嘉兴', '浙江省', 'J'], ['湖州', '浙江省', 'H'], ['绍兴', '浙江省', 'S'], ['金华', '浙江省', 'J'],
    ['衢州', '浙江省', 'Q'], ['舟山', '浙江省', 'Z'], ['台州', '浙江省', 'T'], ['丽水', '浙江省', 'L'],
    ['芜湖', '安徽省', 'W'], ['蚌埠', '安徽省', 'B'], ['淮南', '安徽省', 'H'], ['马鞍山', '安徽省', 'M'],
    ['淮北', '安徽省', 'H'], ['铜陵', '安徽省', 'T'], ['安庆', '安徽省', 'A'], ['黄山', '安徽省', 'H'],
    ['滁州', '安徽省', 'C'], ['阜阳', '安徽省', 'F'], ['宿州', '安徽省', 'S'], ['六安', '安徽省', 'L'],
    ['亳州', '安徽省', 'B'], ['池州', '安徽省', 'C'], ['宣城', '安徽省', 'X'],
    ['莆田', '福建省', 'P'], ['三明', '福建省', 'S'], ['漳州', '福建省', 'Z'], ['南平', '福建省', 'N'],
    ['龙岩', '福建省', 'L'], ['宁德', '福建省', 'N'],
    ['景德镇', '江西省', 'J'], ['萍乡', '江西省', 'P'], ['九江', '江西省', 'J'], ['新余', '江西省', 'X'],
    ['鹰潭', '江西省', 'Y'], ['赣州', '江西省', 'G'], ['吉安', '江西省', 'J'], ['宜春', '江西省', 'Y'],
    ['抚州', '江西省', 'F'], ['上饶', '江西省', 'S'],
    ['淄博', '山东省', 'Z'], ['枣庄', '山东省', 'Z'], ['东营', '山东省', 'D'], ['烟台', '山东省', 'Y'],
    ['潍坊', '山东省', 'W'], ['济宁', '山东省', 'J'], ['泰安', '山东省', 'T'], ['威海', '山东省', 'W'],
    ['日照', '山东省', 'R'], ['临沂', '山东省', 'L'], ['德州', '山东省', 'D'], ['聊城', '山东省', 'L'],
    ['滨州', '山东省', 'B'], ['菏泽', '山东省', 'H'],
    ['开封', '河南省', 'K'], ['洛阳', '河南省', 'L'], ['平顶山', '河南省', 'P'], ['安阳', '河南省', 'A'],
    ['鹤壁', '河南省', 'H'], ['新乡', '河南省', 'X'], ['焦作', '河南省', 'J'], ['濮阳', '河南省', 'P'],
    ['许昌', '河南省', 'X'], ['漯河', '河南省', 'L'], ['三门峡', '河南省', 'S'], ['南阳', '河南省', 'N'],
    ['商丘', '河南省', 'S'], ['信阳', '河南省', 'X'], ['周口', '河南省', 'Z'], ['驻马店', '河南省', 'Z'],
    ['黄石', '湖北省', 'H'], ['十堰', '湖北省', 'S'], ['宜昌', '湖北省', 'Y'], ['襄阳', '湖北省', 'X'],
    ['鄂州', '湖北省', 'E'], ['荆门', '湖北省', 'J'], ['孝感', '湖北省', 'X'], ['荆州', '湖北省', 'J'],
    ['黄冈', '湖北省', 'H'], ['咸宁', '湖北省', 'X'], ['随州', '湖北省', 'S'], ['恩施土家族苗族自治州', '湖北省', 'E'],
    ['株洲', '湖南省', 'Z'], ['湘潭', '湖南省', 'X'], ['衡阳', '湖南省', 'H'], ['邵阳', '湖南省', 'S'],
    ['岳阳', '湖南省', 'Y'], ['常德', '湖南省', 'C'], ['张家界', '湖南省', 'Z'], ['益阳', '湖南省', 'Y'],
    ['郴州', '湖南省', 'C'], ['永州', '湖南省', 'Y'], ['怀化', '湖南省', 'H'], ['娄底', '湖南省', 'L'],
    ['韶关', '广东省', 'S'], ['珠海', '广东省', 'Z'], ['汕头', '广东省', 'S'], ['佛山', '广东省', 'F'],
    ['江门', '广东省', 'J'], ['湛江', '广东省', 'Z'], ['茂名', '广东省', 'M'], ['肇庆', '广东省', 'Z'],
    ['惠州', '广东省', 'H'], ['梅州', '广东省', 'M'], ['汕尾', '广东省', 'S'], ['河源', '广东省', 'H'],
    ['阳江', '广东省', 'Y'], ['清远', '广东省', 'Q'], ['东莞', '广东省', 'D'], ['中山', '广东省', 'Z'],
    ['潮州', '广东省', 'C'], ['揭阳', '广东省', 'J'], ['云浮', '广东省', 'Y'],
    ['三亚', '海南省', 'S'], ['三沙', '海南省', 'S'], ['儋州', '海南省', 'D'],
    ['自贡', '四川省', 'Z'], ['攀枝花', '四川省', 'P'], ['泸州', '四川省', 'L'], ['德阳', '四川省', 'D'],
    ['绵阳', '四川省', 'M'], ['广元', '四川省', 'G'], ['遂宁', '四川省', 'S'], ['内江', '四川省', 'N'],
    ['乐山', '四川省', 'L'], ['南充', '四川省', 'N'], ['眉山', '四川省', 'M'], ['宜宾', '四川省', 'Y'],
    ['广安', '四川省', 'G'], ['达州', '四川省', 'D'], ['雅安', '四川省', 'Y'], ['巴中', '四川省', 'B'],
    ['资阳', '四川省', 'Z'], ['阿坝藏族羌族自治州', '四川省', 'A'], ['甘孜藏族自治州', '四川省', 'G'],
    ['六盘水', '贵州省', 'L'], ['遵义', '贵州省', 'Z'], ['安顺', '贵州省', 'A'], ['毕节', '贵州省', 'B'],
    ['铜仁', '贵州省', 'T'],
    ['曲靖', '云南省', 'Q'], ['玉溪', '云南省', 'Y'], ['保山', '云南省', 'B'], ['昭通', '云南省', 'Z'],
    ['丽江', '云南省', 'L'], ['普洱', '云南省', 'P'], ['临沧', '云南省', 'L'], ['楚雄彝族自治州', '云南省', 'C'],
    ['红河哈尼族彝族自治州', '云南省', 'H'], ['文山壮族苗族自治州', '云南省', 'W'],
    ['西双版纳傣族自治州', '云南省', 'X'], ['大理白族自治州', '云南省', 'D'],
    ['德宏傣族景颇族自治州', '云南省', 'D'], ['怒江傈僳族自治州', '云南省', 'N'],
    ['迪庆藏族自治州', '云南省', 'D'],
    ['铜川', '陕西省', 'T'], ['宝鸡', '陕西省', 'B'], ['咸阳', '陕西省', 'X'], ['渭南', '陕西省', 'W'],
    ['延安', '陕西省', 'Y'], ['汉中', '陕西省', 'H'], ['榆林', '陕西省', 'Y'], ['安康', '陕西省', 'A'],
    ['商洛', '陕西省', 'S'],
    ['金昌', '甘肃省', 'J'], ['白银', '甘肃省', 'B'], ['天水', '甘肃省', 'T'], ['武威', '甘肃省', 'W'],
    ['张掖', '甘肃省', 'Z'], ['平凉', '甘肃省', 'P'], ['酒泉', '甘肃省', 'J'], ['庆阳', '甘肃省', 'Q'],
    ['定西', '甘肃省', 'D'], ['陇南', '甘肃省', 'L'], ['临夏回族自治州', '甘肃省', 'L'],
    ['甘南藏族自治州', '甘肃省', 'G'],
    ['海东', '青海省', 'H'], ['海北藏族自治州', '青海省', 'H'], ['黄南藏族自治州', '青海省', 'H'],
    ['海南藏族自治州', '青海省', 'H'], ['果洛藏族自治州', '青海省', 'G'],
    ['玉树藏族自治州', '青海省', 'Y'], ['海西蒙古族藏族自治州', '青海省', 'H'],
    ['日喀则', '西藏自治区', 'R'], ['昌都', '西藏自治区', 'C'], ['林芝', '西藏自治区', 'L'],
    ['山南', '西藏自治区', 'S'], ['那曲', '西藏自治区', 'N'], ['阿里地区', '西藏自治区', 'A'],
    ['包头', '内蒙古自治区', 'B'], ['乌海', '内蒙古自治区', 'W'], ['赤峰', '内蒙古自治区', 'C'],
    ['通辽', '内蒙古自治区', 'T'], ['鄂尔多斯', '内蒙古自治区', 'E'], ['呼伦贝尔', '内蒙古自治区', 'H'],
    ['巴彦淖尔', '内蒙古自治区', 'B'], ['乌兰察布', '内蒙古自治区', 'W'], ['兴安盟', '内蒙古自治区', 'X'],
    ['锡林郭勒盟', '内蒙古自治区', 'X'], ['阿拉善盟', '内蒙古自治区', 'A'],
    ['柳州', '广西壮族自治区', 'L'], ['桂林', '广西壮族自治区', 'G'], ['梧州', '广西壮族自治区', 'W'],
    ['北海', '广西壮族自治区', 'B'], ['防城港', '广西壮族自治区', 'F'], ['钦州', '广西壮族自治区', 'Q'],
    ['贵港', '广西壮族自治区', 'G'], ['玉林', '广西壮族自治区', 'Y'], ['百色', '广西壮族自治区', 'B'],
    ['贺州', '广西壮族自治区', 'H'], ['河池', '广西壮族自治区', 'H'], ['来宾', '广西壮族自治区', 'L'],
    ['崇左', '广西壮族自治区', 'C'],
    ['石嘴山', '宁夏回族自治区', 'S'], ['吴忠', '宁夏回族自治区', 'W'], ['固原', '宁夏回族自治区', 'G'],
    ['中卫', '宁夏回族自治区', 'Z'],
    ['克拉玛依', '新疆维吾尔自治区', 'K'], ['吐鲁番', '新疆维吾尔自治区', 'T'], ['哈密', '新疆维吾尔自治区', 'H'],
    ['昌吉回族自治州', '新疆维吾尔自治区', 'C'], ['博尔塔拉蒙古自治州', '新疆维吾尔自治区', 'B'],
    ['巴音郭楞蒙古自治州', '新疆维吾尔自治区', 'B'], ['阿克苏地区', '新疆维吾尔自治区', 'A'],
    ['克孜勒苏柯尔克孜自治州', '新疆维吾尔自治区', 'K'], ['喀什地区', '新疆维吾尔自治区', 'K'],
    ['和田地区', '新疆维吾尔自治区', 'H'], ['伊犁哈萨克自治州', '新疆维吾尔自治区', 'Y'],
    ['塔城地区', '新疆维吾尔自治区', 'T'], ['阿勒泰地区', '新疆维吾尔自治区', 'A']
  ]
  const seen = new Set()
  const out = []
  for (const [name, province, letter] of arr) {
    if (seen.has(name)) continue
    seen.add(name)
    out.push({ name, provinceName: province, firstLetter: letter, spell: letter + name })
  }
  return out
})()

// ==== 拉取行政区划 ====
async function loadRegionTree() {
  try {
    const r = await guard(retry(() => regionApi.tree(), 2, 300), null)
    const tree = unwrap(r, null)
    const provList = toList(getPath(tree, 'provinces', []))
    provinces.value = provList
    // 展开所有城市
    const cities = []
    for (const p of provList) {
      const pName = toStr(p.name, '')
      for (const c of toList(p.cities)) {
        cities.push({
          code: toStr(c.code, ''),
          name: toStr(c.name, ''),
          provinceName: pName,
          provinceCode: toStr(p.code, ''),
          firstLetter: toStr(c.firstLetter, '').toUpperCase() || toStr(c.spell, '')[0] || '#',
          spell: toStr(c.spell, ''),
          alias: toList(c.alias)
        })
      }
    }
    allCities.value = cities
    treeLoaded.value = true
    if (letters.value.length) activeLetter.value = letters.value[0]
  } catch (e) {
    // 失败：使用 BUILTIN_FALLBACK_CITIES，不白屏
    treeLoaded.value = false
    allCities.value = []
    if (letters.value.length) activeLetter.value = letters.value[0]
  }
}

// ==== 搜索接口调用（防抖 250ms）====
const doSearch = debounce(async () => {
  const kw = toStr(searchKw.value, '').trim()
  if (!kw) {
    searched.value = false
    searchResult.value = []
    metaSearch.value = { hint: '' }
    return
  }
  searched.value = true
  try {
    const r = await guard(regionApi.search(kw, 80), null)
    const list = toList(unwrap(r, [])).map((c) => ({
      code: toStr(c.code, ''),
      name: toStr(c.name, ''),
      provinceName: toStr(c.provinceName, c.province || ''),
      firstLetter: toStr(c.firstLetter, ''),
      spell: toStr(c.spell, ''),
      alias: toList(c.alias)
    })).filter((c) => c.name)
    searchResult.value = list
    const total = toNum(getPath(r, 'meta.total', list.length), list.length)
    metaSearch.value = { hint: `命中 ${total} 条 · 耗时 ${toNum(getPath(r, 'meta.tookMs', 0), 0)}ms` }
  } catch (_) {
    searchResult.value = []
    metaSearch.value = { hint: '' }
  }
}, 250)

function onSearchInput() {
  doSearch()
}
function onSearchConfirm() {
  doSearch()
  if (searchResult.value.length === 1) {
    onChoose(searchResult.value[0].name)
  }
}
function clearSearch() {
  searchKw.value = ''
  searched.value = false
  searchResult.value = []
  metaSearch.value = { hint: '' }
}

// ==== 4 级定位流水线 ====
async function runLocatePipeline() {
  if (locating.value) return
  locating.value = true
  locateError.value = ''
  locateSource.value = ''
  let city = '', source = ''
  // L2：uni.getLocation + 后端逆地理（未配置 key 时接口会返回 source=not-configured，空城市）
  if (typeof uni.getLocation === 'function') {
    try {
      const loc = await new Promise((resolve, reject) => {
        uni.getLocation({
          type: 'gcj02',
          success: resolve,
          fail: reject,
          timeout: 8000
        })
      })
      try {
        const r = await guard(locationApi.reverse({ lat: loc.latitude, lng: loc.longitude }), null)
        const got = pickCity(getPath(r, 'data.city', ''), '')
        const src = toStr(getPath(r, 'data.source', ''), '')
        if (got) {
          city = got
          source = 'reverse:' + src
        } else if (src === 'not-configured') {
          locateError.value = '定位服务密钥未配置，将按 IP 粗定位或展示默认城市。可在管理后台「配置中心 → App」填写高德/腾讯 key'
        }
      } catch (_) { /* 逆地理失败，继续 */ }
    } catch (err) {
      const msg = toStr(err && (err.errMsg || err.message), '')
      if (/auth|denied|禁止|权限/i.test(msg)) {
        locateError.value = '定位权限未开启，可在系统设置中允许白夜使用定位，或手动选择城市'
      }
    }
  }

  // L3：IP 粗定位
  if (!city) {
    try {
      const r = await guard(locationApi.guessByIp(), null)
      const got = pickCity(getPath(r, 'data.city', ''), '')
      if (got) {
        city = got
        source = 'ip-guess'
      }
    } catch (_) { /* IP 失败，继续 */ }
  }

  // L4：默认值
  if (!city) {
    city = current.value || DEFAULT_CITY
    source = 'fallback'
  }
  current.value = city
  locateSource.value = source
  persistCity(city)
  locating.value = false
}

function sourceText(s) {
  const map = {
    'reverse:amap': '高德逆地理',
    'reverse:tencent': '腾讯逆地理',
    'reverse:not-configured': '未配置定位服务',
    'reverse:bad-input': '定位输入异常',
    'ip-guess': 'IP 粗定位',
    'fallback': '默认城市',
    'cache': '本地缓存'
  }
  if (map[s]) return map[s]
  if (s && s.startsWith('reverse:')) return '逆地理(' + s.slice(8).slice(0, 20) + ')'
  return ''
}

// ==== 滚动到字母 ====
function scrollToLetter(L) {
  activeLetter.value = L
  uni.createSelectorQuery()
    .select(`#letter-${L}`)
    .boundingClientRect()
    .selectViewport()
    .scrollOffset()
    .exec((res) => {
      try {
        const rect = res && res[0]
        const scroll = res && res[1]
        if (rect && scroll) {
          uni.pageScrollTo({ scrollTop: scroll.scrollTop + rect.top - 80, duration: 300 })
        }
      } catch (_) { /* ignore */ }
    })
}

// ==== 选择城市 ====
function onChoose(c) {
  const name = pickCity(c, '')
  if (!name) return
  current.value = name
  persistCity(name)
  locateSource.value = 'manual'
  uni.showToast({ title: `已切换至${name}`, icon: 'none' })
  setTimeout(() => {
    uni.navigateBack({
      delta: 1,
      fail: () => uni.switchTab({ url: '/pages/home/home' })
    })
  }, 380)
}

function onBack() {
  uni.navigateBack({ fail: () => uni.switchTab({ url: '/pages/home/home' }) })
}

// ==== 生命期 ====
onLoad(() => {
  // nothing: 已在模块级从 storage 恢复
})
onMounted(async () => {
  // 并行启动：拉全国行政区划 + 尝试自动定位（互不阻塞，都有兜底）
  const p1 = loadRegionTree()
  const p2 = (async () => {
    try {
      const at = Number(uni.getStorageSync(STORAGE_AT_KEY) || 0)
      if (Date.now() - at < 24 * 3600 * 1000) {
        locateSource.value = 'cache'
        return
      }
      await runLocatePipeline()
    } catch (_) { /* ignore */ }
  })()
  await Promise.all([p1, p2])
})
</script>

<style lang="scss" scoped>
// 依赖 uni.scss 全局注入 theme-baiye 设计变量；不再重复 @use
.page-city { min-height: 100vh; background: $by-bg; padding-bottom: 24rpx; box-sizing: border-box; }

/* 顶部搜索条 */
.search-header {
  position: sticky; top: 0; z-index: 20;
  padding: 60rpx 24rpx 20rpx;
  background: linear-gradient(180deg, $by-bg-soft 0%, color.adjust($by-bg-soft, $alpha: 0.88) 80%, transparent 100%);
  display: flex; align-items: center; gap: 16rpx;
}
.back-btn {
  width: 60rpx; height: 60rpx; display: flex; align-items: center; justify-content: center;
  color: $by-text-1; font-weight: 700;
  .arrow { font-size: 48rpx; line-height: 48rpx; }
}
.search-bar {
  flex: 1; display: flex; align-items: center; gap: 12rpx;
  height: 72rpx; padding: 0 24rpx;
  background: $by-card-bg; border: 1rpx solid $by-border;
  border-radius: 9999rpx;
}
.s-icon { font-size: 28rpx; }
.s-input { flex: 1; height: 68rpx; font-size: 28rpx; color: $by-text-1; background: transparent; }
.s-clear { padding: 6rpx 12rpx; border-radius: 9999rpx; background: $by-soft-card; color: $by-text-3; font-size: 22rpx; }

.section {
  margin: 20rpx 24rpx; padding: 28rpx;
  border-radius: 20rpx; background: $by-card-bg; border: 1rpx solid $by-border;
  &.city-list-card { padding: 20rpx 28rpx 32rpx; }
}
.section-title {
  display: flex; align-items: baseline; justify-content: space-between;
  font-size: 28rpx; font-weight: 700; color: $by-text-1;
  margin-bottom: 20rpx; letter-spacing: 0.5px;
  &::before { content: ''; display: inline-block; width: 6rpx; height: 24rpx; margin-right: 12rpx; vertical-align: -4rpx; border-radius: 4rpx; background: $by-gradient-gold; }
  .meta-hint { color: $by-text-3; font-size: 22rpx; font-weight: 500; }
}
.meta-row {
  display: flex; justify-content: space-between; margin-bottom: 8rpx;
  color: $by-text-3; font-size: 22rpx;
  .meta-warn { color: #ffa940; }
}
.current-row { display: flex; align-items: center; justify-content: space-between; }
.current-city {
  display: inline-flex; align-items: center; gap: 10rpx;
  padding: 18rpx 26rpx; border-radius: 16rpx;
  background: color.adjust($by-gold, $alpha: 0.1);
  color: $by-gold; font-weight: 700; font-size: 30rpx;
  border: 1rpx solid color.adjust($by-gold, $alpha: 0.3);
}
.city-name { letter-spacing: 1px; }
.locating-dot {
  width: 14rpx; height: 14rpx; border-radius: 50%;
  background: $by-gold; animation: pulse 1s infinite;
}
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }
.locate-btn {
  padding: 14rpx 24rpx; border-radius: 12rpx;
  background: $by-soft-card; color: $by-text-2; font-size: 26rpx;
  border: 1rpx solid $by-border;
  &.disabled { opacity: 0.6; }
}
.locate-error {
  margin-top: 18rpx; padding: 14rpx 18rpx;
  border-radius: 12rpx; background: rgba(255,77,79,0.08); color: #ff7a45;
  font-size: 24rpx; line-height: 1.6;
  .err-link { color: $by-gold; text-decoration: underline; }
}

.hot-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18rpx; }
.hot-item {
  padding: 18rpx 0; text-align: center;
  border-radius: 14rpx;
  background: $by-soft-card; color: $by-text-1;
  font-size: 28rpx;
  border: 1rpx solid $by-border;
  transition: all .15s;
  &:active, &.active { transform: scale(0.97); background: color.adjust($by-gold, $alpha: 0.12); color: $by-gold; border-color: color.adjust($by-gold, $alpha: 0.3); }
}

.letter-bar { display: flex; flex-wrap: wrap; gap: 12rpx; }
.letter-chip {
  min-width: 52rpx; padding: 8rpx 14rpx; text-align: center;
  border-radius: 12rpx; background: $by-soft-card; color: $by-text-3;
  font-size: 24rpx; font-weight: 600;
  border: 1rpx solid $by-border;
  &.active { background: $by-gradient-gold; color: #0B0F1A; border-color: transparent; }
}

.group-letter {
  display: flex; align-items: center; gap: 10rpx;
  font-size: 26rpx; font-weight: 800;
  margin: 16rpx 4rpx 10rpx;
  color: $by-gold; letter-spacing: 1px;
  .group-count {
    font-size: 20rpx; font-weight: 500; color: $by-text-3;
    padding: 2rpx 10rpx; border-radius: 8rpx; background: $by-soft-card;
  }
}
.city-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 22rpx 12rpx;
  border-bottom: 1rpx solid $by-border;
  color: $by-text-1; font-size: 28rpx;
  transition: background .15s;
  &:last-child { border-bottom: none; }
  &:active, &.selected { background: $by-soft-card; }
  .city-info { flex: 1; display: flex; flex-direction: column; gap: 4rpx; }
  .city-main { font-weight: 500; }
  .city-sub { font-size: 22rpx; color: $by-text-3; }
  .checked { color: $by-gold; font-weight: 700; }
}
.empty-s { padding: 40rpx 10rpx; display: flex; flex-direction: column; align-items: center; gap: 14rpx; }
.empty-emoji { font-size: 56rpx; }
.empty-text { color: $by-text-3; font-size: 26rpx; }
.bottom-safe { height: calc(40rpx + env(safe-area-inset-bottom)); }
</style>
